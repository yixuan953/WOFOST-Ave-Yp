/* Generated file by local.mk; do not edit.  */
extern package_create_instance_callback pk_disklabel_create_instance;
